<?php

declare(strict_types=1);

namespace MikrotikService\Exception;

class CurlException extends \Exception {
    
}