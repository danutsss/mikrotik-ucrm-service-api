<?php

declare(strict_types = 1);

namespace MikrotikService\Data;

/** data entered in plugin's config */
class PluginData extends UcrmData {
    /** @var string */
    public $mktUser;

    /** @var string */
    public $mktPass;

    /** @var string */
    public $displayedErrors;

    /** @var string */
    public $logging_level;
}