<?php

declare(strict_types = 1);

namespace MikrotikService\Data;

/** data entered in plugin's config */
class PluginData extends UcrmData {
    /** @var string */
    public $ipAddresses;

    /** @var string */
    public $displayedErrors;

    /** @var string */
    public $logging_level;
}