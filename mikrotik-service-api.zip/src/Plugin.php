<?php

declare(strict_types=1);


namespace MikrotikService;

use Psr\Log\LogLevel;
use MikrotikService\Factory\MikrotikDataFactory;
use MikrotikService\Service\OptionsManager;
use MikrotikService\Service\PluginDataValidator;
use MikrotikService\Service\Logger;
use MikrotikService\Service\RouterosAPI;
use MikrotikService\Service\UcrmApi;
use Ubnt\UcrmPluginSdk\Service\UcrmApi as ServiceUcrmApi;

class Plugin
{
    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var OptionsManager
     */
    private $optionsManager;

    /**
     * @var PluginDataValidator
     */
    private $pluginDataValidator;

    /**
     * @var MikrotikDataFactory
     */
    private $mikrotikDataFactory;
    
    public function __construct(
        Logger $logger,
        OptionsManager $optionsManager,
        PluginDataValidator $pluginDataValidator,
        MikrotikDataFactory $mikrotikDataFactory
    )
    {
        $this->logger = $logger;
        $this->optionsManager = $optionsManager;
        $this->pluginDataValidator = $pluginDataValidator;
        $this->mikrotikDataFactory = $mikrotikDataFactory;
    }

    public function run(): void
    {
        if (PHP_SAPI === 'fpm-fcgi') {
            $this->logger->info('Mikrotik Service API over HTTP started');
            $this->processHttpRequest();
            $this->logger->info('HTTP request processing ended.');
        } elseif (PHP_SAPI === 'cli') {
            $this->logger->info('Mikrotik Service API over CLI started');
            $this->processCli();
            $this->logger->info('CLI process ended.');
        } else {
            throw new \UnexpectedValueException('Unknown PHP_SAPI type: ' . PHP_SAPI);
        }
    }

    private function processCli(): void
    {
        if ($this->pluginDataValidator->validate()) {
            $this->logger->info('Validating config');
            $this->optionsManager->load();
        }
    }

    private function processHttpRequest(): void
    {
        include 'Functions.php';

        $pluginData = $this->optionsManager->load();
        if ($pluginData->logging_level) {
            $this->logger->setLogLevelThreshold(LogLevel::DEBUG);
        }

        $userInput = file_get_contents('php://input');
        if (! $userInput) {
            $this->logger->warning('no input');

            return;
        }

        $jsonData = @json_decode($userInput, true, 10);
        if (! isset($jsonData['uuid'])) {
            $this->logger->error('JSON error: ' . json_last_error_msg());

            return;
        }

        $mikrotik = $this->mikrotikDataFactory->getObject($jsonData);
        if ($mikrotik->changeType === 'test') {
            $this->logger->info('Webhook test successful.');

            return;
        }
        

        if (! $mikrotik->clientId) {
            $this->logger->warning('No client specified, cannot notify them.');

            return;
        }

        $deviceId = randomGUID();

        $IPs = cidrToRange($pluginData -> ipAddresses);
        $ipAddress = array_rand($IPs, 1);
        
        /** Mikrotik API Connection */
        $mktApi = new RouterosAPI;
        $mktApi -> debug = true;

        $devicePass = generateRandPassword();

        $clientId = (isset($this -> mikrotikDataFactory -> getClientData($mikrotik)['id']) ? 
                            $this -> mikrotikDataFactory -> getClientData($mikrotik)['id'] : null);

        $customId = (isset($this -> mikrotikDataFactory -> getClientData($mikrotik)['userIdent']) ? 
                            $this -> mikrotikDataFactory -> getClientData($mikrotik)['userIdent'] : null);

        $fullName = (isset($this -> mikrotikDataFactory -> getClientData($mikrotik)['lastName']) ? 
                        $this -> mikrotikDataFactory -> getClientData($mikrotik)['lastName'] : null) . ' ' .
                    (isset($this -> mikrotikDataFactory -> getClientData($mikrotik)['firstName']) ?
                        $this -> mikrotikDataFactory -> getClientData($mikrotik)['firstName'] : null);
        
        $fullAddress = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['street1']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['street1'] : null) . ' ' .
                       (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['street2']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['street2'] : null);
    
        $clientSiteId = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['unmsClientSiteId']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['unmsClientSiteId'] : null);

        $serviceId = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['id']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['id'] : null);

        $servicePlanType = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['servicePlanType']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['servicePlanType'] : null);

        /** Custom Attributes for: Service IP, Address, PPPoE Username & Password visible in Client Zone */
        $serviceIp = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['attributes'][0]['value']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['attributes'][0]['value'] : null);

        $servicePPPoEUser = (isset($this -> mikrotikDataFactory -> getServiceData($mikrotik)['attributes'][1]['value']) ?
                        $this -> mikrotikDataFactory -> getServiceData($mikrotik)['attributes'][1]['value'] : null);

        static $i = 0;
        $sameNames = [];
        $deviceName = $deviceNameOriginal = "07NAV" . $customId;

        try {
            if($mikrotik -> changeType === 'insert') {
                if($servicePlanType === 'Internet') {
                    $internetPlan = UcrmApi::doRequest('devices/blackboxes/config', 'POST',
                    "{
                        \"deviceId\": \"$deviceId\",
                        \"hostname\": \"$deviceName\",
                        \"modelName\": \"Router\",
                        \"macAddress\": \"00:00:0a:00:00:aa\",
                        \"deviceRole\": \"router\",
                        \"siteId\": \"$clientSiteId\",
                        \"pingEnabled\": true,
                        \"ipAddress\": \"$IPs[$ipAddress]\",
                        \"ubntDevice\": false,
                        \"note\": \"$fullAddress\",
                        \"interfaces\": [
                            {
                                \"id\": \"$deviceName\",
                                \"position\": 0,
                                \"name\": \"$deviceName\",
                                \"mac\": \"00:00:0a:00:00:aa\",
                                \"type\": \"eth\",
                                \"addresses\": [
                                    \"$IPs[$ipAddress]/32\"
                                ]
                            }
                        ]
                    }");

                    //var_dump($internetPlan);

                    if($mktApi -> connect("93.119.183.66", "admin", "stf@07internet")) {
                        do {
                            // First - check if duplicate exists...
                            $sameNames = $mktApi -> comm("/ppp/secret/getall", array(
                                ".proplist" => ".id",
                                "?name" => $deviceName
                            ));

                            // Second - update and prepare for rechecking...
                            if(count($sameNames) > 0) {
                                $i ++;
                                $deviceName = $deviceNameOriginal . "-" . $i;
                            }

                            // Finally - if check failed, cycle and check again with the new updated name...
                        }
                        while(count($sameNames) > 0);

                        // If you need the original value of "Device Name" you can retain it.
                        unset($i, $deviceNameOriginal);

                        $mktApi -> comm("/ppp/secret/add", array(
                            "name" => $deviceName,
                            "remote-address" => $IPs[$ipAddress],
                            "password" => $devicePass,
                            "service" => "pppoe",
                            "comment" => $fullName . ' / ' . $fullAddress
                        ));
                    }

                    /** UPDATE Custom Attribute for: Service IP, Service PPPoE Username, Password and Service Address */
                    $updateServiceIP = curl_init();

                    curl_setopt($updateServiceIP, CURLOPT_URL, 'https://uisp.07internet.ro/crm/api/v1.0/clients/services/' . $serviceId);
                    curl_setopt($updateServiceIP, CURLOPT_RETURNTRANSFER, TRUE);
                    curl_setopt($updateServiceIP, CURLOPT_HEADER, FALSE);

                    curl_setopt($updateServiceIP, CURLOPT_CUSTOMREQUEST, "PATCH");

                    curl_setopt($updateServiceIP, CURLOPT_POSTFIELDS, "{
                        \"attributes\": [
                            {
                                \"value\": \"$IPs[$ipAddress]\",
                                \"customAttributeId\": 45
                            }
                        ]
                    }");

                    curl_setopt($updateServiceIP, CURLOPT_HTTPHEADER, array(
                        "Content-Type: application/json",
                        "X-Auth-App-Key: HS9hdWcdsV34MXGy/VKKloywDwZeVORNGAfZlHQNQM2sAQM03bSPOodm/9eQ1qpH"
                    ));

                    $responseServiceIP = curl_exec($updateServiceIP);
                    curl_close($updateServiceIP);

                    //var_dump($responseServiceIP);

                    if($responseServiceIP) {
                        $updateServiceUser = curl_init();

                        curl_setopt($updateServiceUser, CURLOPT_URL, 'https://uisp.07internet.ro/crm/api/v1.0/clients/services/' . $serviceId);
                        curl_setopt($updateServiceUser, CURLOPT_RETURNTRANSFER, TRUE);
                        curl_setopt($updateServiceUser, CURLOPT_HEADER, FALSE);

                        curl_setopt($updateServiceUser, CURLOPT_CUSTOMREQUEST, "PATCH");

                        curl_setopt($updateServiceUser, CURLOPT_POSTFIELDS, "{
                            \"attributes\": [
                                {
                                    \"value\": \"$deviceName\",
                                    \"customAttributeId\": 46
                                }
                            ]
                        }");

                        curl_setopt($updateServiceUser, CURLOPT_HTTPHEADER, array(
                            "Content-Type: application/json",
                            "X-Auth-App-Key: HS9hdWcdsV34MXGy/VKKloywDwZeVORNGAfZlHQNQM2sAQM03bSPOodm/9eQ1qpH"
                        ));

                        $responseServiceUser = curl_exec($updateServiceUser);
                        curl_close($updateServiceUser);

                        //var_dump($responseServiceUser);

                        if($responseServiceUser) {
                            $updateServicePass = curl_init();

                            curl_setopt($updateServicePass, CURLOPT_URL, 'https://uisp.07internet.ro/crm/api/v1.0/clients/services/' . $serviceId);
                            curl_setopt($updateServicePass, CURLOPT_RETURNTRANSFER, TRUE);
                            curl_setopt($updateServicePass, CURLOPT_HEADER, FALSE);

                            curl_setopt($updateServicePass, CURLOPT_CUSTOMREQUEST, "PATCH");

                            curl_setopt($updateServicePass, CURLOPT_POSTFIELDS, "{
                                \"attributes\": [
                                    {
                                        \"value\": \"$devicePass\",
                                        \"customAttributeId\": 47
                                    }
                                ]
                            }");

                            curl_setopt($updateServicePass, CURLOPT_HTTPHEADER, array(
                                "Content-Type: application/json",
                                "X-Auth-App-Key: HS9hdWcdsV34MXGy/VKKloywDwZeVORNGAfZlHQNQM2sAQM03bSPOodm/9eQ1qpH"
                            ));

                            $responseServicePass = curl_exec($updateServicePass);
                            curl_close($updateServicePass);

                            //var_dump($responseServicePass);

                            if($responseServicePass) {
                                $updateServiceAddr = curl_init();

                                curl_setopt($updateServiceAddr, CURLOPT_URL, 'https://uisp.07internet.ro/crm/api/v1.0/clients/services/' . $serviceId);
                                curl_setopt($updateServiceAddr, CURLOPT_RETURNTRANSFER, TRUE);
                                curl_setopt($updateServiceAddr, CURLOPT_HEADER, FALSE);

                                curl_setopt($updateServiceAddr, CURLOPT_CUSTOMREQUEST, "PATCH");

                                curl_setopt($updateServiceAddr, CURLOPT_POSTFIELDS, "{
                                    \"attributes\": [
                                        {
                                            \"value\": \"$fullAddress\",
                                            \"customAttributeId\": 48
                                        }
                                    ]
                                }");

                                curl_setopt($updateServiceAddr, CURLOPT_HTTPHEADER, array(
                                    "Content-Type: application/json",
                                    "X-Auth-App-Key: HS9hdWcdsV34MXGy/VKKloywDwZeVORNGAfZlHQNQM2sAQM03bSPOodm/9eQ1qpH"
                                ));

                                $responseServiceAddr = curl_exec($updateServiceAddr);
                                curl_close($updateServiceAddr);

                                //var_dump($responseServiceAddr);
                            }
                        }
                    }

                    $this -> logger -> info(var_dump($this -> mikrotikDataFactory -> getServiceData($mikrotik)['attributes']));

                } elseif($servicePlanType === 'General') {
                    if($mktApi -> connect("93.119.183.66", "admin", "stf@07internet")) {
                        do {
                            // First - check if duplicate exists...
                            $sameNames = $mktApi -> comm("/ppp/secret/getall", array(
                                ".proplist" => ".id",
                                "?name" => $deviceName
                            ));

                            // Second - update and prepare for rechecking...
                            if(count($sameNames) > 0) {
                                $i ++;
                                $deviceName = $deviceNameOriginal . "-" . $i;
                            }

                            // Finally - if check failed, cycle and check again with the new updated name...
                        }
                        while(count($sameNames) > 0);

                        /** ?? La servicePlanType === General, sa pun in client zone atributele pentru servicii ?? */

                        $mktApi -> comm("/ppp/secret/add", array(
                            "name" => $deviceName,
                            "remote-address" => "1.1.1.1",
                            "password" => $devicePass,
                            "service" => "pppoe",
                            "comment" => $fullName . ' / ' . $fullAddress
                        ));
                    }
                }
                $mktApi -> disconnect();
            } 
            
            if($mikrotik -> changeType === 'suspend') {
                if($mktApi -> connect("93.119.183.66", "admin", "stf@07internet")) {
                    $printUsers = $mktApi -> comm("/ppp/secret/getall", array(
                        ".proplist" => ".id",
                        "?name" => $servicePPPoEUser
                    ));

                    $mktApi -> comm("/ppp/secret/set", array(
                        ".id" => $printUsers[0][".id"],
                        "?remote-address" => "1.1.1.1"
                    ));

                    $mktApi -> comm("/ppp/active/remove", array(
                        ".id" => $printUsers[0][".id"]
                    ));
                }
                $mktApi -> disconnect();
            }
            
            if($mikrotik -> changeType === 'end') {
                if($mktApi -> connect("93.119.183.66", "admin", "stf@07internet")) {
                    $printUsers = $mktApi -> comm("/ppp/secret/getall", array(
                        ".proplist" => ".id",
                        "?name" => $servicePPPoEUser
                    ));

                    $mktApi -> comm("/ppp/active/remove", array(
                        ".id" => $printUsers[0][".id"]
                    ));

                    $mktApi -> comm("/ppp/secret/remove", array(
                        ".id" => $printUsers[0][".id"]
                    ));

                    var_dump($printUsers);
                }
                $mktApi -> disconnect();
            }
            
            if($mikrotik -> changeType === 'unsuspend') {
                if($mktApi -> connect("93.119.183.66", "admin", "stf@07internet")) {
                    $printUsers = $mktApi -> comm("/ppp/secret/getall", array(
                        ".proplist" => ".id",
                        "?name" => $servicePPPoEUser
                    ));

                    $mktApi -> comm("/ppp/secret/set", array(
                        ".id" => $printUsers[0][".id"],
                        "remote-address" => $serviceIp
                    ));
                }

                $mktApi -> disconnect();
            }
            
        } catch (\Exception $ex) {
            $this->logger->error($ex->getMessage());
            $this->logger->warning($ex->getTraceAsString());
        }
    }
}